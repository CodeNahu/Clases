#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>
#include "funciones.h"

int pideDato ()

{
    int dato;

    printf("\nIngrese ID a buscar: ");
    scanf("%d", &dato);

return dato;

}
