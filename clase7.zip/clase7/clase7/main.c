#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#define TAM 2

typedef struct
{
    int legajo;
    int edad;
    int notaParcial1;
    int notaParcial2;
    char nombre [20];
    char sexo;
    float promedio;
} eAlumno;

void mostrarAlumno (eAlumno al);
void mostrarAlumnos(eAlumno vec [], int tam);

int main()
{
    eAlumno lista[TAM];
    for (int i=0; i<TAM; i++){

        printf("Ingrese legajo: ");
        scanf("%d", &lista[i].legajo);
        printf("Ingrese nombre: ");
        fflush(stdin);
        gets(lista[i].nombre);
        printf("Ingrese edad: ");
        scanf("%d",&lista[i].edad);
        printf("Ingrese sexo: ");
        gets(&lista[i].sexo);
        printf("Ingrese Nota 1: ");
        scanf("%d",&lista[i].notaParcial1);
        printf("Ingrese Nota 2: ");
        scanf("%d",&lista[i].notaParcial2);

        lista.promedio = (float) (alumno1.nota1 + alumno1.nota2)/2;
        mostrarAlumnos(lista,TAM);
        return 0;
    }

    void mostrarAlumnos (eAlumno vec [], int tam)
    {

        printf(" Legajo Nombre Edad Sexo Nota1 Nota2 Promedio");
        for (int i=0; i<tam; i++)
        {
            mostrarAlumno(vec[i]);
        }
        printf("\n\n");
    }
}
void mostrarAlumno (eAlumno al){
 printf("%d" "%c" "%d" "%c" "%d" "%d" "%2.f", al.legajo, al.nombre, al.edad, al.sexo, al.nota1, al.nota2, al.promedio);
